This is a starter template for Mobiscroll (https://mobiscroll.com)

This template contains a Mobiscroll build - trial or licensed verison - depending on your account.
You can run the app using the Ionic CLI. If you don't have it installed, please go to http://ionicframework.com/getting-started/
Open a terminal window (command prompt) and run the following commands:

$ sudo npm install

This (npm install) will install all the necessary plugins and tools.

$ ionic serve

This (ionic serve) will run the ionic project in browser. For testing the app on a device or emulator run:

$ ionic cordova platform add ios
$ ionic cordova run ios

You can do the same for Android by substituting ios for android.

Feel free to reach out on https://mobiscroll.com if there is any trouble.