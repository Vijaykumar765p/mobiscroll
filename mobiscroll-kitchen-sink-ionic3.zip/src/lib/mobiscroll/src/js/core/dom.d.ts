import { mobiscroll } from './mobiscroll';
export { mobiscroll };
