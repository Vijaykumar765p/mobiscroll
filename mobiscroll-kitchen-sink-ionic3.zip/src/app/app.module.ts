import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { Globals } from './globals';

import { MbscModule } from '../lib/mobiscroll/js/mobiscroll.angular.min.js';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { AboutPage } from '../pages/about/about';
import { SettingsSection } from '../pages/settings/settings';

import { CalendarPage } from '../pages/calendar/calendar';
import { CardsPage } from '../pages/cards/cards';
import { DatetimePage } from '../pages/datetime/datetime';
import { ColorPage } from '../pages/color/color';
import { EventcalendarPage } from '../pages/eventcalendar/eventcalendar';
import { SelectPage } from '../pages/select/select';
import { FormsPage } from '../pages/forms/forms';
import { ListviewPage } from '../pages/listview/listview';
import { ImagePage } from '../pages/image/image';
import { MeasurementPage } from '../pages/measurement/measurement';
import { OptionListPage } from '../pages/optionlist/optionlist';
import { NumpadPage } from '../pages/numpad/numpad';
import { RangePage } from '../pages/range/range';
import { ScrollerPage } from '../pages/scroller/scroller';
import { ScrollviewPage } from '../pages/scrollview/scrollview';
import { NavigationPage } from '../pages/navigation/navigation';
import { TimerPage } from '../pages/timer/timer';
import { TimespanPage } from '../pages/timespan/timespan';
import { TreelistPage } from '../pages/treelist/treelist';
import { WidgetPage } from '../pages/widget/widget';
import { AlertPage } from '../pages/alert/alert';
import { NotificationPage } from '../pages/notifications/notifications';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    AboutPage,
    CalendarPage,
    CardsPage,
    DatetimePage,
    ColorPage,
    EventcalendarPage,
    SelectPage,
    FormsPage,
    ListviewPage,
    ImagePage,
    MeasurementPage,
    OptionListPage,
    NumpadPage,
    RangePage,
    ScrollerPage,
    ScrollviewPage,
    NavigationPage,
    TimerPage,
    TimespanPage,
    TreelistPage,
    WidgetPage,
    AlertPage,
    NotificationPage,
    SettingsSection
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MbscModule,
    FormsModule,
    IonicModule.forRoot(MyApp, {
      mode: 'ios',
      scrollAssist: false,
      autoFocusAssist: false
    }),
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    AboutPage,
    HomePage,
    CalendarPage,
    CardsPage,
    DatetimePage,
    ColorPage,
    EventcalendarPage,
    SelectPage,
    FormsPage,
    ListviewPage,
    ImagePage,
    MeasurementPage,
    OptionListPage,
    NumpadPage,
    RangePage,
    ScrollerPage,
    ScrollviewPage,
    NavigationPage,

    TimerPage,
    TimespanPage,
    TreelistPage,
    WidgetPage,
    AlertPage,
    NotificationPage,
    SettingsSection
  ],
  providers: [
    Globals,
    StatusBar,
    SplashScreen,
    { provide: ErrorHandler, useClass: IonicErrorHandler }
  ]
})
export class AppModule { }
