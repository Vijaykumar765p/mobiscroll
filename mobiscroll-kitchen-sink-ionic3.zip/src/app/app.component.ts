import { Component, ViewChild } from '@angular/core';
import { Nav, Platform } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { HomePage } from '../pages/home/home';
import { AboutPage } from '../pages/about/about';
import { CalendarPage } from '../pages/calendar/calendar';
import { CardsPage } from '../pages/cards/cards';
import { DatetimePage } from '../pages/datetime/datetime';
import { ColorPage } from '../pages/color/color';
import { EventcalendarPage } from '../pages/eventcalendar/eventcalendar';
import { SelectPage } from '../pages/select/select';
import { FormsPage } from '../pages/forms/forms';
import { ListviewPage } from '../pages/listview/listview';

import { ImagePage } from '../pages/image/image';
import { MeasurementPage } from '../pages/measurement/measurement';
import { OptionListPage  } from '../pages/optionlist/optionlist'
import { NumpadPage } from '../pages/numpad/numpad';
import { RangePage } from '../pages/range/range';
import { ScrollerPage } from '../pages/scroller/scroller';
import { ScrollviewPage } from '../pages/scrollview/scrollview';
import { NavigationPage } from '../pages/navigation/navigation';
import { TimerPage } from '../pages/timer/timer';
import { TimespanPage } from '../pages/timespan/timespan';
import { TreelistPage } from '../pages/treelist/treelist';
import { WidgetPage } from '../pages/widget/widget';
import { AlertPage } from '../pages/alert/alert';
import { NotificationPage } from '../pages/notifications/notifications';

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;

  rootPage: any = HomePage;

  pages: Array<{title: string, component: any}>;

  constructor(public platform: Platform, public statusBar: StatusBar, public splashScreen: SplashScreen) {
    this.initializeApp();

    // used for an example of ngFor and navigation
    this.pages = [
       { title: 'Home', component: HomePage },
       { title: 'Calendar', component: CalendarPage },
       { title: 'Datetime', component: DatetimePage },
       { title: 'Cards', component: CardsPage },
       { title: 'Color', component: ColorPage },
       { title: 'Eventcalendar', component: EventcalendarPage },
       { title: 'Select', component: SelectPage },
       { title: 'Forms', component: FormsPage },
       { title: 'Alerts', component: AlertPage },
       { title: 'Notifications', component: NotificationPage },
       { title: 'Listview', component: ListviewPage },
       { title: 'Image', component: ImagePage },
       { title: 'Measurement', component: MeasurementPage },
       { title: 'Option List', component: OptionListPage },
       { title: 'Numpad', component: NumpadPage },
       { title: 'Range', component: RangePage },
       { title: 'Scroller', component: ScrollerPage },
       { title: 'Scrollview', component: ScrollviewPage },
       { title: 'Navigation', component: NavigationPage },
       { title: 'Timer', component: TimerPage },
       { title: 'Timespan', component: TimespanPage },
       { title: 'Treelist', component: TreelistPage },
       { title: 'Widget', component: WidgetPage },
       { title: 'About', component: AboutPage }
    ];

  }

  initializeApp() {
    this.platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }

  openPage(page) {
    // Reset the content nav to have just this page
    // we wouldn't want the back button to show in this scenario
    this.nav.setRoot(page.component);
  }
}
