import { Component, ViewChild } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Globals } from '../../app/globals';

@Component({
  selector: 'page-image',
  templateUrl: 'image.html'
})
export class ImagePage {
  image = 'Citroen';
  isActive: boolean;

  @ViewChild('mbscImage')
  imageComp: any;

  imageSettings = {
    theme: this.globals.theme,
    lang: this.globals.lang,
    placeholder: 'Please Select ...',
    inputClass: 'text-input text-input-md',
    enhance: true,
    circular: false
  }

  /******* Dynamic theme and language change section **********/

  constructor(public navCtrl: NavController, public globals: Globals) {
    this.globals.events$.subscribe(() => this.updateSettings())
  }

  updateSettings() {
    if (this.isActive) {
      this.imageComp.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
    }
  }

  ionViewDidEnter() {
    this.isActive = true;
  }

  ionViewWillLeave() {
    this.isActive = false;
  }

  /************************************************************/

}
