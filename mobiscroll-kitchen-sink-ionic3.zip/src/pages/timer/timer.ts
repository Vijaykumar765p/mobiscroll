import { Component, ViewChild } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Globals } from '../../app/globals';

@Component({
  selector: 'page-timer',
  templateUrl: 'timer.html'
})
export class TimerPage {
  timer: number;

  @ViewChild('mbscTimer')
  timerComp: any;

  timerSettings = {
    theme: this.globals.theme,
    lang: this.globals.lang,
    display: 'inline',
    targetTime: 10,
    maxWheel: 'minutes',
    minWidth: 100,
    onFinish: function () {
      alert('Countdown finished!');
    }
  }

  /******* Dynamic theme and language change section **********/

  isActive: boolean;

  constructor(public navCtrl: NavController, public globals: Globals) {
    this.globals.events$.subscribe(() => this.updateSettings())
  }

  updateSettings() {
    if (this.isActive) {
      this.timerComp.instance.stop();
      this.timerComp.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
    }
  }

  ionViewDidEnter() {
    this.isActive = true;
  }

  ionViewWillLeave() {
    this.isActive = false;
  }

  /************************************************************/

}
