import { Component, ViewChild } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Globals } from '../../app/globals';

@Component({
  selector: 'cards-calendar',
  templateUrl: 'cards.html'
})
export class CardsPage {
  myDate = new Date();
  isActive: boolean;

  settings: any = {
    theme: this.globals.theme,
    lang: this.globals.lang
  }


  /******* Dynamic theme and language change section **********/

  @ViewChild('page')
  pageComp: any;

  @ViewChild('simpleCard')
  card1: any;

  @ViewChild('reminderCard')
  card2: any;

  @ViewChild('articleCard')
  card3: any;

  constructor(public navCtrl: NavController, public globals: Globals) {
    this.globals.events$.subscribe(() => this.updateSettings());
  }

  updateSettings() {
    if (this.isActive) {
      this.pageComp.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
      this.card1.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
      this.card2.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
      this.card3.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
    }
  }

  ionViewDidEnter() {
    this.isActive = true;
  }

  ionViewWillLeave() {
    this.isActive = false;
  }

  /************************************************************/
}
