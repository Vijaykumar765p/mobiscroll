import { Component, ViewChild } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Globals } from '../../app/globals';

@Component({
  selector: 'page-widget',
  templateUrl: 'widget.html'
})
export class WidgetPage {
  @ViewChild('mbscWidget')
  widgetComp: any;
  settings = {
    theme: this.globals.theme,
    lang: this.globals.lang,
    display: 'center',
    buttons: [],
    anchor: '#show'
  };

  /******* Dynamic theme and language change section **********/
  isActive: boolean;

  constructor(public navCtrl: NavController, public globals: Globals) {
    this.globals.events$.subscribe(() => this.updateSettings())
  }

  updateSettings() {
    if (this.isActive) {
      this.widgetComp.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
    }
  }

  ionViewDidEnter() {
    this.isActive = true;
    this.updateSettings();
  }

  ionViewWillLeave() {
    this.isActive = false;
  }

  /************************************************************/
}
