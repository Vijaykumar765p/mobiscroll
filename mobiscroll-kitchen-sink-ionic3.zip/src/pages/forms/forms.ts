import { Component, ViewChild } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Globals } from '../../app/globals';

@Component({
  selector: 'page-forms',
  templateUrl: 'forms.html'
})
export class FormsPage {
  isActive: boolean;
  checkbox1 = true;
  switch1 = true;
  slider1 = 25;
  slider2 = 50;
  segmented1 = "week";
  @ViewChild('mbscForm')
  formComp: any;
  @ViewChild('mbscSlider')
  sliderComp: any;
  @ViewChild('mbscSliderSteps')
  sliderStepsComp: any;
  @ViewChild('mbscProgress')
  progressComp: any;
  @ViewChild('mbscSwitch')
  switchComp: any;
  @ViewChild('mbscSwitch2')
  switch2Comp: any;

  formSettings = {
    theme: this.globals.theme,
    lang: this.globals.lang
  }

  constructor(public navCtrl: NavController, public globals: Globals) {
    this.globals.events$.subscribe(() => this.updateSettings())
  }

  updateSettings() {
    if (this.isActive) {
      this.formComp.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
      this.sliderComp.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
      this.sliderStepsComp.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
      this.progressComp.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
      this.switch2Comp.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
      this.switchComp.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
    }
  }

  ionViewDidEnter() {
    this.isActive = true;
  }

  ionViewWillLeave() {
    this.isActive = false;
  }

}
