import { Component, ViewChild } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Globals } from '../../app/globals';

@Component({
  selector: 'page-rating',
  templateUrl: 'rating.html'
})
export class RatingPage {
  isActive:boolean;
  ratingSettings = {
    theme: this.globals.theme,
    lang: this.globals.lang,
    display: 'bottom',
    values: ['Very Bad', 'Bad', 'Okay', 'Good', 'Very Good'],
    label: 'Rating',
    showOnFocus: true
  }
  @ViewChild('mbscRating')
  ratingComp: any;

  /******* Dynamic theme and language change section **********/

  constructor(public navCtrl: NavController,public globals:Globals) {
    this.globals.events$.subscribe(() => this.updateSettings())
  }

  updateSettings() {
    if (this.isActive) {
      this.ratingComp.instance.option({'theme': this.globals.theme, 'lang': this.globals.lang });
    }
  }

  ionViewDidEnter() {
    this.isActive = true;
  }

  ionViewWillLeave() {
    this.isActive = false;
  }

  /************************************************************/

}
