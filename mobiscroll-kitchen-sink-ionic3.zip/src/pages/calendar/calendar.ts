import { Component, ViewChild } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Globals } from '../../app/globals';

@Component({
  selector: 'page-calendar',
  templateUrl: 'calendar.html'
})
export class CalendarPage {
  myDate = new Date();
  isActive: boolean;

  /* Single Day select calendar demo settings */

  @ViewChild('mbscCalendar')
  calendarComp: any;

  calendarSettings = {
    theme: this.globals.theme,
    lang: this.globals.lang
  }

  /* Multi day select calendar demo settings */

  @ViewChild('mbscCalendarMulti')
  calendarMultiComp: any
  now = new Date();
  myDates = [new Date(), new Date(this.now.setDate(5))];

  calendarMultiSettings = {
    theme: this.globals.theme,
    lang: this.globals.lang,
    select: 'multiple'
  }

  /******* Dynamic theme and language change section **********/

  constructor(public navCtrl: NavController, public globals: Globals) {
    this.globals.events$.subscribe(() => this.updateSettings());
  }

  updateSettings() {
    if (this.isActive) {
      this.calendarComp.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
      this.calendarComp.instance.setVal(this.myDate, true); // need override the selected value because of the localization dateformat difference 
      this.calendarMultiComp.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang, defaultValue: this.myDates });
      this.calendarMultiComp.instance.setVal(this.myDates, true); // need override the selected value because of the localization dateformat difference 
    }
  }

  ionViewDidEnter() {
    this.isActive = true;
  }

  ionViewWillLeave() {
    this.isActive = false;
  }

  /************************************************************/
}
