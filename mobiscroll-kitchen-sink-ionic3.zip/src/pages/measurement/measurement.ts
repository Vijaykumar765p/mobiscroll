import { Component, ViewChild } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Globals } from '../../app/globals';

@Component({
  selector: 'page-measurement',
  templateUrl: 'measurement.html'
})
export class MeasurementPage {

  /* distance demo settings */

  @ViewChild('mbscDistance')
  distanceComp: any;

  distance: string;
  distanceSettings: any = {
    theme: this.globals.theme,
    lang: this.globals.lang
  };

  /* speed demo settings */

  @ViewChild('mbscSpeed')
  speedComp: any;

  speed: string;
  speedSettings: any = {
    theme: this.globals.theme,
    lang: this.globals.lang
  };

  /* temperature demo settings */

  @ViewChild('mbscTemp')
  tempComp: any;

  temperature: string;
  temperatureSettings: any = {
    theme: this.globals.theme,
    lang: this.globals.lang,
    units: ['c', 'f'],
    max: 100
  };

  /* mass demo settings */

  @ViewChild('mbscMass')
  massComp: any;

  massSettings = {
    theme: this.globals.theme,
    lang: this.globals.lang
  }

  /* force demo settings */

  @ViewChild('mbscForce')
  forceComp: any;

  forceSettings = {
    theme: this.globals.theme,
    lang: this.globals.lang
  }

  /******* Dynamic theme and language change section **********/
  isActive: boolean;

  constructor(public navCtrl: NavController, public globals: Globals) {
    this.globals.events$.subscribe(() => this.updateSettings())
  }

  updateSettings() {
    if (this.isActive) {
      this.tempComp.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
      this.speedComp.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
      this.distanceComp.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
      this.massComp.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
      this.forceComp.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
    }
  }

  ionViewDidEnter() {
    this.isActive = true;
  }

  ionViewWillLeave() {
    this.isActive = false;
  }

  /************************************************************/

}
