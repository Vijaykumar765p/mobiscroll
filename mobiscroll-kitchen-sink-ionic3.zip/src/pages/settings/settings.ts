import { Component } from '@angular/core';
import { Globals } from '../../app/globals';
import { mobiscroll } from '../../lib/mobiscroll/js/mobiscroll.angular.min.js';

@Component({
  selector: 'settings-section',
  templateUrl: 'settings.html'
})
export class SettingsSection {
  theme: string;
  lang: string;

  themes: Array<any> = [
    { value: "ios", text: "iOS" },
    { value: "material", text: "Material" },
    { value: "windows", text: "Windows" },
  ];

  languages: Array<any> = [
    { value: "en", text: "English" },
    { value: "ar", text: "Arabic" },
    { value: "bg", text: "Bulgarian" },
    { value: "ca", text: "Català" },
    { value: "cs", text: "Cestina" },
    { value: "hr", text: "Croatian" },
    { value: "zh", text: "Chinese" },
    { value: "da", text: "Dansk" },
    { value: "de", text: "Deutsch" },
    { value: "es", text: "Español" },
    { value: "fr", text: "Français" },
    { value: "el", text: "Greek" },
    { value: "fi", text: "Finnish" },
    { value: "hi", text: "Hindi" },
    { value: "ko", text: "Korean" },
    { value: "it", text: "Italiano" },
    { value: "ja", text: "Japanese" },
    { value: "lt", text: "Lietuvių" },
    { value: "hu", text: "Magyar" },
    { value: "nl", text: "Nederlands" },
    { value: "no", text: "Norsk" },
    { value: "pl", text: "Polski" },
    { value: "pt-PT", text: "Português" },
    { value: "ro", text: "Româna" },
    { value: "sk", text: "Slovencina" },
    { value: "sr", text: "Serbian" },
    { value: "sv", text: "Svenska" },
    { value: "tr", text: "Türkçe" },
    { value: "vi", text: "Vietnamese" },
    { value: "ru", text: "Русский" },
    { value: "he", text: "עברית" },
    { value: "fa", text: "فارسی" },
  ];


  constructor(public globals: Globals) {
    this.theme = globals.theme;
    this.lang = globals.lang;
  }

  updateSettings() {
    var isThemeChanged = this.theme != this.globals.theme;
    mobiscroll.toast({
      theme: 'ios',
      message: (isThemeChanged ? 'Theme' : 'Language') + ' changed to ' + (isThemeChanged ? (this.themes.find((themeObj) => { return themeObj.value == this.theme })).text : (this.languages.find((langObj) => { return langObj.value == this.lang })).text)
    });

    this.globals.theme = this.theme;
    this.globals.lang = this.lang;

    if (this.globals.newEvent) {
      this.globals.newEvent('settingsChanged');
    }
  }

}
