import { Component, ViewChild } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Globals } from '../../app/globals';

let fromValues = ['Before 1960', 1970, 1980, 1990, 1995, 2000, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015],
    toValues = [1970, 1980, 1990, 1995, 2000, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016];

@Component({
    selector: 'page-scroller',
    templateUrl: 'scroller.html'
})
export class ScrollerPage {
    myDate = new Date();
    isActive: boolean;
    @ViewChild('mbscScroller')
    scrollerComp: any;
    scrollerOptions: any = {
        theme: this.globals.theme,
        lang: this.globals.lang,
        display: 'center',
        rows: this.globals.theme == "wp" ? 5 : 10,
        wheels: [
            [{
                circular: false,
                data: fromValues,
                label: 'From'
            }, {
                circular: false,
                data: toValues,
                label: 'To'
            }]
        ],
        sshowOnFocus: true,
        showLabel: true,
        minWidth: 130,
        cssClass: 'md-daterange',
        validate: function (event, inst) {
            var i,
                values = event.values,
                disabledValues = [];

            for (i = 0; i < toValues.length; ++i) {
                if (toValues[i] <= values[0]) {
                    disabledValues.push(toValues[i]);
                }
            }

            return {
                disabled: [
                    [], disabledValues
                ]
            }
        },
        formatValue: function (data) {
            return data[0] + ' - ' + data[1];
        },
        parseValue: function (valueText) {
            if (valueText) {
                return valueText.replace(/\s/gi, '').split('-');
            }
            return [1990, 2010];
        }
    }

    /******* Dynamic theme and language change section **********/

    constructor(public navCtrl: NavController, public globals: Globals) {
        this.globals.events$.subscribe(() => this.updateSettings())
    }

    updateSettings() {
        if (this.isActive) {
            this.scrollerComp.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
        }
    }

    ionViewDidEnter() {
        this.isActive = true;
    }

    ionViewWillLeave() {
        this.isActive = false;
    }


    /************************************************************/

}
