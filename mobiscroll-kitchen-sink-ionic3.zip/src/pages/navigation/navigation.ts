import { Component, ViewChild } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Globals } from '../../app/globals';

@Component({
  selector: 'navigation-timer',
  templateUrl: 'navigation.html'
})
export class NavigationPage {

  currentTab: string = 'downloaded';

  tabSettings: any = {
    display: 'inline',
    theme: this.globals.theme,
    lang: this.globals.lang
  };

  navData = [{
    id: '1',
    text: 'Item 1',
    selected: false,
    icon: 'home',
    disabled: true,
    badge: null
  }, {
    id: '2',
    text: 'Item 2',
    selected: false,
    icon: 'user4',
    disabled: false,
    badge: null
  }, {
    id: '3',
    text: 'Item 3',
    selected: true,
    icon: 'connection',
    disabled: false,
    badge: null
  }, {
    id: '4',
    text: 'Item 4',
    selected: false,
    icon: 'cogs',
    disabled: false,
    badge: null
  }, {
    id: '5',
    text: 'Item 5',
    selected: false,
    icon: 'download',
    disabled: false,
    badge: null
  }, {
    id: '6',
    text: 'Item 6',
    selected: false,
    icon: 'ion-bluetooth',
    disabled: true,
    badge: null
  }, {
    id: '7',
    text: 'Item 7',
    selected: false,
    icon: 'volume-medium',
    disabled: false,
    badge: null
  }];

  iconTextMenu = {
    theme: this.globals.theme,
    lang: this.globals.lang,
    type: 'hamburger',
    menuText: 'Menu'
  };

  //

  @ViewChild('mbscNavMore')
  mbscNavMore: any;

  @ViewChild('mbscNav')
  mbscNav: any;

  @ViewChild('mbscHamNav')
  mbscHamNav: any;

  @ViewChild('form')
  formComp: any;

  /******* Dynamic theme and language change section **********/

  isActive: boolean;

  constructor(public navCtrl: NavController, public globals: Globals) {
    this.globals.events$.subscribe(() => this.updateSettings())
  }

  updateSettings() {
    if (this.isActive) {
      this.formComp.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
      this.mbscNav.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
      this.mbscHamNav.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
      this.mbscNavMore.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
    }
  }

  ionViewDidEnter() {
    this.isActive = true;
  }

  ionViewWillLeave() {
    this.isActive = false;
  }

  /************************************************************/

}
