import { Component, ViewChild } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Globals } from '../../app/globals';

@Component({
  selector: 'page-treelist',
  templateUrl: 'treelist.html'
})
export class TreelistPage {
  isActive: boolean;
  @ViewChild('mbscTreelist')
  listComp: any;
  listSettings: any = {
    theme: this.globals.theme,
    lang: this.globals.lang,
    width: [76, 116, 116],
    inputClass: 'text-input text-input-md',
    placeholder: 'Please Select ...',
    labels: ['Region', 'Supervisor', 'Tech']
  }

  /******* Dynamic theme and language change section **********/

  constructor(public navCtrl: NavController, public globals: Globals) {
    this.globals.events$.subscribe(() => this.updateSettings())
  }

  updateSettings() {
    if (this.isActive) {
      this.listComp.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
    }
  }

  ionViewDidEnter() {
    this.isActive = true;
    this.updateSettings();
  }

  ionViewWillLeave() {
    this.isActive = false;
  }

  /************************************************************/

}
