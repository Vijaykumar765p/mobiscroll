import { Component, ViewChild } from '@angular/core';
import { NavController } from 'ionic-angular';
import { mobiscroll } from '../../lib/mobiscroll/js/mobiscroll.angular.min.js';
import { Globals } from '../../app/globals';

@Component({
  selector: 'page-menustrip',
  templateUrl: 'menustrip.html'
})
export class MenustripPage {
  menustripSettings: any = {
      theme: 'ios',
      display: 'inline',
      type: 'options',
      onItemTap: function (event, inst) {
          mobiscroll.toast({
              message: event.target.textContent + (event.target.getAttribute('ng-reflect-selected') != 'true' ? ' ON' : ' OFF')
          });
      }
  };

  menustripItems = [{
      selected: true,
      icon: "connection",
      text: "Wi-Fi"
  }, {
      selected: false,
      icon: "ion-bluetooth",
      text: "Bluetooth"
  }, {
      selected: false,
      icon: "location",
      text: "Location"
  }, {
      selected: false,
      icon: "fa-rotate-left",
      text: "Screenrotation"
  }, {
      selected: false,
      icon: "volume-medium",
      text: "Sound"
  }, {
      selected: false,
      icon: "download",
      text: "Data"
  }, {
      selected: false,
      icon: "foundation-minus-circle",
      text: "Blocking mode"
  }, {
      selected: false,
      icon: "airplane",
      text: "Airplanemode"
  }, {
      selected: true,
      icon: "fa-leaf",
      text: "Powersaving"
  }, {
      selected: false,
      icon: "alarm2",
      text: "Alarm"
  }, {
      selected: false,
      icon: "ion-android-system-windows",
      text: "Multiwindow"
  }];

  @ViewChild('mbscMenustrip')
  menustripComp: any;

  /******* Dynamic theme and language change section **********/

  isActive:boolean;

  constructor(public navCtrl: NavController,public globals:Globals) {
    this.globals.events$.subscribe(() => this.updateSettings())
  }

  updateSettings() {
    if (this.isActive) {
      this.menustripComp.instance.option({'theme': this.globals.theme, 'lang': this.globals.lang });
    }
  }

  ionViewDidEnter() {
    this.isActive = true;
  }

  ionViewWillLeave() {
    this.isActive = false;
  }

  /************************************************************/

}
