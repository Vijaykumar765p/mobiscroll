import { Component, ViewChild, ViewChildren } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Globals } from '../../app/globals';
import { MbscCard } from '../../lib/mobiscroll/js/mobiscroll.angular.min.js';

@Component({
    selector: 'scrollview-timer',
    templateUrl: 'scrollview.html'
})
export class ScrollviewPage {

    scrollViewOptions: any = {
        theme: this.globals.theme,
        lang: this.globals.lang,
        layout: 'fixed',
        itemWidth: 134
    }

    newGames = [{
        image: 'assets/images/worms3.png',
        title: 'Worms 3',
        dev: 'Team 17 Digital Limited',
        rank: 4.2
    }, {
        image: 'assets/images/candycrush.png',
        title: 'Candy Crush Saga',
        dev: 'King',
        rank: 4.3
    }, {
        image: 'assets/images/angrybirds.png',
        title: 'Angry Birds',
        dev: 'Rovino',
        rank: 4.4
    }, {
        image: 'assets/images/nfs.png',
        title: 'Need for Speed™ No Limits',
        dev: 'ELECTRONIC ARTS',
        rank: 4.3
    }, {
        image: 'assets/images/heartstone.png',
        title: 'Hearthstone',
        dev: 'Blizzard Entertainment Inc.',
        rank: 4.2
    }, {
        image: 'assets/images/fruitninja.png',
        title: 'Fruit Ninja',
        dev: 'Halfbrick Studios',
        rank: 4.3
    }, {
        image: 'assets/images/subwaysurf.png',
        title: 'Subway Surfers',
        dev: 'Kiloo',
        rank: 4.4
    }, {
        image: 'assets/images/templerun.png',
        title: 'Temple Run',
        dev: 'Imangi Studios',
        rank: 4.3
    }, {
        image: 'assets/images/minecraft.png',
        title: 'Minecraft: Pocket Edition',
        dev: 'Mojang ',
        rank: 4.4
    }];


    mediaVideo = [{
        image: 'assets/images/vlc.png',
        title: 'VLC for Android',
        dev: 'Videolabs ',
        rank: 4.3
    }, {
        image: 'assets/images/realplayer.png',
        title: 'RealPlayer®',
        dev: 'RealNetworks, Inc.',
        rank: 4.3
    }, {
        image: 'assets/images/motogal.png',
        title: 'Motorola Gallery',
        dev: 'Motorola Mobility LLC. ',
        rank: 3.9
    }, {
        image: 'assets/images/revesemov.png',
        title: 'Reverse Movie FX',
        dev: 'Bizo Mobile',
        rank: 4.6
    }, {
        image: 'assets/images/sure.png',
        title: 'SURE Universal Remote',
        dev: 'Tekoia Ltd.',
        rank: 4.4
    }, {
        image: 'assets/images/ringdriod.png',
        title: 'Ringdroid',
        dev: 'Ringdroid Team ',
        rank: 4.4
    }, {
        image: 'assets/images/funny.png',
        title: 'Funny Camera - Video Booth Fun',
        dev: 'Kiloo',
        rank: 4.1
    }, {
        image: 'assets/images/gif.png',
        title: 'GIF Keyboard',
        dev: 'IRiffsy, Inc.',
        rank: 4.1
    }, {
        image: 'assets/images/bs.png',
        title: 'BSPlayer',
        dev: 'BSPlayer media',
        rank: 4.4
    }, {
        image: 'assets/images/vac.png',
        title: 'video audio cutter',
        dev: 'mytechnosound ',
        rank: 4.3
    }];


    @ViewChild('mediaScroll')
    media: any;

    @ViewChild('gameScroll')
    games: any;

    @ViewChild('page')
    pageComp: any;

    @ViewChildren(MbscCard) cards: any;

    /********* Dynamic theme and language change section **********/

    isActive: boolean;

    constructor(public navCtrl: NavController, public globals: Globals) {
        this.globals.events$.subscribe(() => this.updateSettings())
    }

    updateSettings() {
        if (this.isActive) {
            this.cards.forEach(cardInst => {
                cardInst.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
            })

            this.pageComp.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
        }
    }

    ionViewDidEnter() {
        this.isActive = true;
    }

    ionViewWillLeave() {
        this.isActive = false;
    }

    /************************************************************/

}
