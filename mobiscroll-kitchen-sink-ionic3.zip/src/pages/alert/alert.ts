import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { mobiscroll } from '../../lib/mobiscroll/js/mobiscroll.angular.min.js';
import { Globals } from '../../app/globals';

mobiscroll.settings = {
    theme: 'ios'
}

@Component({
    selector: 'page-alert',
    templateUrl: 'alert.html'
})
export class AlertPage {

    constructor(public navCtrl: NavController, public globals: Globals) {
    }

    showAlert() {
        mobiscroll.alert({
            theme: this.globals.theme,
            lang: this.globals.lang,
            title: 'Cellular Data is Turned Off for "Safari"',
            message: 'You can turn on cellular data for this app in Settings.',
            callback: function () {
                mobiscroll.toast({
                    message: 'Alert closed'
                });
            }
        });
    }
    showConfirm() {
        mobiscroll.confirm({
            theme: this.globals.theme,
            title: 'Use location service?',
            message: 'Help apps determine location. This means sending anonymous location data, even when no apps are running.',
            okText: 'Agree',
            cancelText: 'Disagree',
            callback: function (res) {
                mobiscroll.toast({
                    message: res ? 'Agreed' : 'Disagreed'
                });
            }
        });
    }

    showPrompt() {
        mobiscroll.prompt({
            theme: this.globals.theme,
            lang: this.globals.lang,
            title: 'Sign in to iTunes Store',
            message: 'Enter the Apple ID password for "hello@mobiscroll.com".',
            placeholder: 'Password',
            inputType: 'password',
            callback: function (value) {
                mobiscroll.toast({
                    message: 'The password: ' + value
                });
            }
        });
    }

}
