import { Component, ViewChild } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Globals } from '../../app/globals';

@Component({
  selector: 'page-range',
  templateUrl: 'range.html'
})
export class RangePage {
  isActive: boolean;
  range: Array<Date> = [new Date(2017, 3, 10), new Date(2017, 3, 17)];
  timeRange: Array<Date> = [new Date(2017, 3, 10, 5, 15), new Date(2017, 3, 10, 10, 15)];

  /* range demo settings */

  @ViewChild('mbscRange')
  rangeComp: any;

  rangeSettings: any = {
    theme: this.globals.theme,
    lang: this.globals.lang
  };

  /* time range demo settings */
  @ViewChild('mbscTimeRange')
  timeRangeComp: any;

  timeRangeSettings: any = {
    theme: this.globals.theme,
    lang: this.globals.lang,
    controls: ['time'],
    maxWidth: 100
  };

  /* date & time demo settings */
  @ViewChild('mbscDTRange')
  dtRangeComp: any;

  dtRangeSettings: any = {
    theme: this.globals.theme,
    lang: this.globals.lang,
    controls: ['date', 'time'],
    dateWheels: '|D M d|',
    cssClass: 'scroller-range'
  };

  /******* Dynamic theme and language change section **********/

  constructor(public navCtrl: NavController, public globals: Globals) {
    this.globals.events$.subscribe(() => this.updateSettings())
  }

  updateSettings() {
    if (this.isActive) {
      this.rangeComp.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
      this.rangeComp.instance.setVal(this.range, true); // need override the selected value because of the localization dateformat difference 
      this.timeRangeComp.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
      this.timeRangeComp.instance.setVal(this.timeRange, true); // need override the selected value because of the localization dateformat difference 
      this.dtRangeComp.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
      this.dtRangeComp.instance.setVal(this.range, true); // need override the selected value because of the localization dateformat difference 
    }
  }

  ionViewDidEnter() {
    this.isActive = true;
  }

  ionViewWillLeave() {
    this.isActive = false;
  }

  /************************************************************/
}
