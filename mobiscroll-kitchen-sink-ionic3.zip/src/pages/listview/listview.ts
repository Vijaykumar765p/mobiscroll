import { Component, ViewChild } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Globals } from '../../app/globals';

@Component({
    selector: 'page-listview',
    templateUrl: 'listview.html'
})
export class ListviewPage {
    isActive: boolean;
    ids = 6;
    data = [{
        id: 1,
        title: 'Work order #0001',
        status: 'Assigned'
    }, {
        id: 2,
        title: 'Work order #0002',
        status: 'Assigned'
    }, {
        id: 3,
        title: 'Work order #0003',
        status: 'Assigned'
    }, {
        id: 4,
        title: 'Work order #0004',
        status: 'Assigned'
    }, {
        id: 5,
        title: 'Work order #0005',
        status: 'Assigned'
    }, {
        id: 6,
        title: 'Work order #0006',
        status: 'Assigned'
    }];

    @ViewChild('mbscListview')
    listviewComp: any;
    listviewSettings: any = {
        theme: this.globals.theme,
        lang: this.globals.lang,
        iconSlide: true,
        striped: true,
        stages: [{
            percent: 25,
            color: 'crimson',
            icon: 'checkmark',
            text: 'Complete',
            action: (event, inst) => {
                this.data[event.index].status = 'Completed';
            }
        }, {
            percent: -50,
            color: 'red',
            icon: 'remove',
            text: 'Delete',
            confirm: true,
            action: (event, inst) => {
                this.data.splice(event.index, 1);
                return false;
            }
        }, {
            percent: 50,
            color: 'green',
            icon: 'plus',
            text: 'Spawn',
            action: (event, inst) => {
                this.data.splice(event.index + 1, 0, {
                    id: ++this.ids,
                    title: 'Work order #000' + this.ids + ' created from WO #000',
                    status: 'Assigned'
                });
            }
        }, {
            percent: -25,
            color: 'olive',
            icon: 'clock',
            text: 'Pending',
            action: (event, inst) => {
                this.data[event.index].status = 'Pending';
            }
        }]
    };

    /******* Dynamic theme and language change section **********/

    constructor(public navCtrl: NavController, public globals: Globals) {
        this.globals.events$.subscribe(() => this.updateSettings())
    }

    updateSettings() {
        if (this.isActive) {
            this.listviewComp.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
        }
    }

    ionViewDidEnter() {
        this.isActive = true;
    }

    ionViewWillLeave() {
        this.isActive = false;
    }

    /************************************************************/

}
