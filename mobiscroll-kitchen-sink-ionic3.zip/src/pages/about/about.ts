import { Component } from '@angular/core';
import { mobiscroll } from '../../lib/mobiscroll/js/mobiscroll.angular.min.js';

@Component({
  selector: 'page-about',
  templateUrl: 'about.html',
})
export class AboutPage {
  mbscVersion: string = (mobiscroll as any).version;
  buildDate: Date = new Date(/* Date */);
}
