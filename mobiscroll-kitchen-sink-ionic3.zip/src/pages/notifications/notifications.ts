import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { mobiscroll } from '../../lib/mobiscroll/js/mobiscroll.angular.min.js';
import { Globals } from '../../app/globals';

mobiscroll.settings = {
  theme: 'ios'
}

@Component({
  selector: 'page-notification',
  templateUrl: 'notifications.html'
})
export class NotificationPage {

  constructor(public navCtrl: NavController, public globals: Globals) { }

  showToast() {
    mobiscroll.toast({
      theme: this.globals.theme,
      message: 'Message sent'
    });
  }

  showSnackbar() {
    mobiscroll.snackbar({
      theme: this.globals.theme,
      message: 'Your draft has been discarded'
    });
  }

  showSnackbarAction() {
    mobiscroll.snackbar({
      theme: this.globals.theme,
      message: 'Connection timed out. Showing limited messages.',
      button: {
        text: 'Retry',
        action: function () {
          mobiscroll.toast({
            message: 'Retrying...'
          });
        }
      }
    });
  }

}
