import { Component, ViewChild } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Globals } from '../../app/globals';

@Component({
  selector: 'page-timespan',
  templateUrl: 'timespan.html'
})
export class TimespanPage {
  timespan: number;
  isActive: boolean;

  @ViewChild('mbscTimespan')
  timespanComp: any;

  timespanSettings = {
    theme: this.globals.theme,
    lang: this.globals.lang,
    display: 'bottom',
    wheelOrder: 'iiss',
    minWidth: 120
  }

  constructor(public navCtrl: NavController, public globals: Globals) {
    this.globals.events$.subscribe(() => this.updateSettings())
  }

  updateSettings() {
    if (this.isActive) {
      this.timespanComp.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
    }
  }

  ionViewDidEnter() {
    this.isActive = true;
    this.updateSettings();
  }

  ionViewWillLeave() {
    this.isActive = false;
  }

}
