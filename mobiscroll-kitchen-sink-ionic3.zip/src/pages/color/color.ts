import { Component, ViewChild } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Globals } from '../../app/globals';

@Component({
  selector: 'page-color',
  templateUrl: 'color.html',
})
export class ColorPage {

  /* multiple select color demo settings */
  @ViewChild('mbscColorMultiple')
  colorCompMultile: any;
  myColors = [];

  colorSettings = {
      theme: this.globals.theme,
      lang: this.globals.lang,
      enhance: false,
      select: 'multiple'
  }

  /* single select color demo settings */

  @ViewChild('mbscColor')
  colorCompSingle: any;
  myColor = '#f44437';

  colorSingle = {
      theme: this.globals.theme,
      lang: this.globals.lang,
      enhance: false
  }

  /******* Dynamic theme and language change section **********/
  isActive:boolean;

  constructor(public navCtrl: NavController,public globals:Globals) {
    this.globals.events$.subscribe(() => this.updateSettings());
  }

  updateSettings() {
    if (this.isActive) {
      this.colorCompSingle.instance.option({'theme': this.globals.theme, 'lang': this.globals.lang });
      this.colorCompMultile.instance.option({'theme': this.globals.theme, 'lang': this.globals.lang });
    }
  }

  ionViewDidEnter() {
    this.isActive = true;
  }

  ionViewWillLeave() {
    this.isActive = false;
  }

  /************************************************************/

}
