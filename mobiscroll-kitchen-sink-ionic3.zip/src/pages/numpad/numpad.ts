import { Component, ViewChild } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Globals } from '../../app/globals';

@Component({
  selector: 'page-numpad',
  templateUrl: 'numpad.html'
})
export class NumpadPage {

  /* Numpad decimal demo settings */
  @ViewChild('mbscNumpad')
  numpadComp: any;

  number: number;
  numpadSettings: any = {
    theme: this.globals.theme,
    lang: this.globals.lang,
    display: 'bottom',
    min: 1,
    scale: 2,
    preset: 'decimal'
  };

  /* Numpad timespan demo settings */

  @ViewChild('mbscNumpadTimeSpan')
  numpadCompTimespan: any;

  timespan: number;
  numpadTimespanSettings: any = {
    theme: this.globals.theme,
    lang: this.globals.lang,
    display: 'bottom',
    preset: 'timespan'
  };

  /* Numpad time demo settings */

  @ViewChild('mbscNumpadTime')
  numpadCompTime: any

  time: number;
  numpadTimeSettings: any = {
    theme: this.globals.theme,
    lang: this.globals.lang,
    display: 'bottom',
    preset: 'time',
    timeFormat: 'HH:ii'
  };

  /* Numpad pin demo settings */

  @ViewChild('mbscNumpadPin')
  numpadCompPin: any;

  numpadPinSettings = {
    template: 'dddd',
    allowLeadingZero: true,
    placeholder: '-',
    mask: '*',
    validate: function (event, inst) {
      return {
        invalid: event.values.length != 4
      };
    }
  }

  /******* Dynamic theme and language change section **********/

  isActive: boolean;

  constructor(public navCtrl: NavController, public globals: Globals) {
    this.globals.events$.subscribe(() => this.updateSettings())
  }

  updateSettings() {
    if (this.isActive) {
      this.numpadComp.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
      this.numpadCompTime.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
      this.numpadCompTimespan.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
      this.numpadCompPin.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
    }
  }

  ionViewDidEnter() {
    this.isActive = true;
  }

  ionViewWillLeave() {
    this.isActive = false;
  }

  /************************************************************/

}
