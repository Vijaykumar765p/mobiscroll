import { Component, ViewChild } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Globals } from '../../app/globals';

@Component({
  selector: 'page-datetime',
  templateUrl: 'datetime.html'
})
export class DatetimePage {
  now = new Date();
  myDate = new Date();
  myTime = new Date();
  myDateTime = new Date();

  /* date demo settings */

  @ViewChild('mbscDate')
  dateComp: any;

  dateSettings = {
    theme: this.globals.theme,
    lang: this.globals.lang
  }

  /* time demo settings */

  @ViewChild('mbscTime')
  timeComp: any;

  timeSettings = {
    theme: this.globals.theme,
    lang: this.globals.lang
  }

  /* datetime demo settings */

  @ViewChild('mbscDateTime')
  dateTimeChild: any;

  dateTimeSettings = {
    theme: this.globals.theme,
    lang: this.globals.lang,
    min: new Date(this.now.getFullYear() - 1, this.now.getMonth(), this.now.getDate()),
    max: new Date(this.now.getFullYear() + 1, this.now.getMonth(), this.now.getDate()),
    dateWheels: '|D M d|'
  }

  /******* Dynamic theme and language change section **********/

  isActive: boolean;

  constructor(public navCtrl: NavController, public globals: Globals) {
    this.globals.events$.subscribe(() => this.updateSettings())
  }

  updateSettings() {
    if (this.isActive) {
      this.timeComp.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
      this.timeComp.instance.setVal(this.myTime, true); // need override the selected value because of the localization dateformat difference 
      this.dateComp.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
      this.dateComp.instance.setVal(this.myDate, true); // need override the selected value because of the localization dateformat difference 
      this.dateTimeChild.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
      this.dateTimeChild.instance.setVal(this.myDateTime, true); // need override the selected value because of the localization dateformat difference 
    }
  }

  ionViewDidEnter() {
    this.isActive = true;
    this.updateSettings();
  }

  ionViewWillLeave() {
    this.isActive = false;
  }

  /************************************************************/

}
