import { Component } from '@angular/core';
import { NavController, MenuController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(public navCtrl: NavController, public menuCtrl: MenuController) {
    // open the side menu by default only for the mobiscroll ionic page
    if (window.location.href.indexOf('ionickitchensink') != -1) {
      menuCtrl.open();
    }
  }

}
