import { Component, ViewChild } from '@angular/core';
import { NavController } from 'ionic-angular';
import { mobiscroll } from '../../lib/mobiscroll/js/mobiscroll.angular.min.js';
import { Globals } from '../../app/globals';

@Component({
    selector: 'page-optionlist',
    templateUrl: 'optionlist.html'
})
export class OptionListPage {
    optionSettings: any = {
        // lang,
        // theme,
        itemWidth: 72
    };

    optionItems = [{
        selected: true,
        icon: "connection",
        text: "Wi-Fi"
    }, {
        selected: false,
        icon: "ion-bluetooth",
        text: "Bluetooth"
    }, {
        selected: false,
        icon: "location",
        text: "Location"
    }, {
        selected: false,
        icon: "fa-rotate-left",
        text: "Screen rotation"
    }, {
        selected: true,
        icon: "volume-medium",
        text: "Sound"
    }, {
        selected: false,
        icon: "download",
        text: "Data"
    }, {
        selected: false,
        icon: "foundation-minus-circle",
        text: "Blocking mode"
    }, {
        selected: false,
        icon: "airplane",
        text: "Airplane mode"
    }, {
        selected: true,
        icon: "fa-leaf",
        text: "Power saving"
    }, {
        selected: false,
        icon: "alarm2",
        text: "Alarm"
    }, {
        selected: false,
        icon: "ion-android-system-windows",
        text: "Multi window"
    }];

    showToast(option) {
        mobiscroll.toast({
            message: option.text + (option.selected ? ' ON' : ' OFF')
        });
    }

    @ViewChild('optionList')
    optionList: any;

    /******* Dynamic theme and language change section **********/

    isActive: boolean;

    constructor(public navCtrl: NavController, public globals: Globals) {
        this.globals.events$.subscribe(() => this.updateSettings())
    }

    updateSettings() {
        if (this.isActive) {
            this.optionList.instance.option({ 'theme': this.globals.theme, 'lang': this.globals.lang });
        }
    }

    ionViewDidEnter() {
        this.isActive = true;
    }

    ionViewWillLeave() {
        this.isActive = false;
    }

    /************************************************************/

}
