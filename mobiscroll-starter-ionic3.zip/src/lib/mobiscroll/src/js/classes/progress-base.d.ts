import { Base, MbscCoreOptions } from '../core/core';

export class ProgressBase extends Base {
    constructor(element: any, settings: MbscCoreOptions);
}