import { Component } from '@angular/core';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  todoData = [{
      text: "Do the laundry",
      checked: true
  }, {
      text: "Don't forget mom's birthday!",
      checked: true
  }, {
      text: "Buy new shoes"
  }, {
      text: "Need ketchup for pizza"
  }];

  contentSettings = {
      theme: 'ios'
  };

  todoDate = new Date();

  todoList = {
      sortable: {
          handle: 'left'
      },
      stages: {
          left: [{
              key: 'stage1',
              icon: 'plus',
              color: '#31c6e7',
              text: 'Add',
              action: (event) => {
                    this.todoData.splice(event.index + 1, 0, {
                        text: "New Todo"
                    });
              }
          }],
          right: [{
              key: 'stage2',
              color: '#009688',
              text: 'Remove',
              icon: 'remove',
              action: (event) => {
                  this.todoData.splice(event.index, 1);
                  return false;
              }
          }]
      }
  };

}
